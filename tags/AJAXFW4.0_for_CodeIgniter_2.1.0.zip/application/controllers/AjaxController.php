<?php

class AjaxController {
	
	function main()
	{
		
		require_once(FCPATH.'ajaxfw.php');
	}
	
}