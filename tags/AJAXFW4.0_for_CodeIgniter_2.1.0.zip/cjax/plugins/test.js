
function test(params) {
	var param = params.array();
	CJAX.echo('test function: '+param[0]);
	
} 