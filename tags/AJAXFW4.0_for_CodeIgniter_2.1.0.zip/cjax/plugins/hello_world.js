/**
 Hello_world application,  a desmotration starting point for creating a CJAX plugin.
**/

/**
file name should be consistent with the function name.
 
 **/


function hello_world(a,b,c)
{
	
	alert('HELLO_WORLD PLUGIN --   '+a+'  '+b+'  '+c);
	
}