
function cool(params)
{
	params = params.array();
	
	alert('argument: '+params[0]);
}

