=====================

======CJAX 4.0=======

AJAX Framework
For CodeIgniter_2.1.0


written by cj galindo.
cjxxi21@gmail.com
phpbugs.com

skype: ajaxboy21